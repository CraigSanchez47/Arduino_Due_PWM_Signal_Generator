﻿
namespace Arduino_GUI_PWM_Control
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.DutyCycleButton = new System.Windows.Forms.Button();
            this.PhaseShiftButton = new System.Windows.Forms.Button();
            this.FrequencyLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.FrequencyButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ConnectionPanel = new System.Windows.Forms.Panel();
            this.ButtonDisconnect = new System.Windows.Forms.Button();
            this.ButtonConnect = new System.Windows.Forms.Button();
            this.ComboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.LabelBaudRate = new System.Windows.Forms.Label();
            this.ComboBoxPort = new System.Windows.Forms.ComboBox();
            this.ButtonScanPort = new System.Windows.Forms.Button();
            this.ConnectionTitle = new System.Windows.Forms.Label();
            this.TimerSerial = new System.Windows.Forms.Timer(this.components);
            this.ConnectionPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM6";
            // 
            // DutyCycleButton
            // 
            this.DutyCycleButton.Location = new System.Drawing.Point(86, 94);
            this.DutyCycleButton.Name = "DutyCycleButton";
            this.DutyCycleButton.Size = new System.Drawing.Size(185, 58);
            this.DutyCycleButton.TabIndex = 0;
            this.DutyCycleButton.Text = "Duty Cycle Mode";
            this.DutyCycleButton.UseVisualStyleBackColor = true;
            this.DutyCycleButton.Click += new System.EventHandler(this.DutyCycleButton_Click);
            // 
            // PhaseShiftButton
            // 
            this.PhaseShiftButton.Location = new System.Drawing.Point(86, 174);
            this.PhaseShiftButton.Name = "PhaseShiftButton";
            this.PhaseShiftButton.Size = new System.Drawing.Size(185, 66);
            this.PhaseShiftButton.TabIndex = 1;
            this.PhaseShiftButton.Text = "Phase Shift Mode";
            this.PhaseShiftButton.UseVisualStyleBackColor = true;
            this.PhaseShiftButton.Click += new System.EventHandler(this.PhaseShiftButton_Click);
            this.PhaseShiftButton.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.PhaseShiftButton_Click);
            // 
            // FrequencyLabel
            // 
            this.FrequencyLabel.AutoSize = true;
            this.FrequencyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FrequencyLabel.Location = new System.Drawing.Point(158, 52);
            this.FrequencyLabel.Name = "FrequencyLabel";
            this.FrequencyLabel.Size = new System.Drawing.Size(133, 17);
            this.FrequencyLabel.TabIndex = 2;
            this.FrequencyLabel.Text = "Frequency (kHz):";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(311, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(131, 22);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(311, 108);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(131, 22);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(311, 190);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(131, 22);
            this.textBox3.TabIndex = 5;
            // 
            // FrequencyButton
            // 
            this.FrequencyButton.Location = new System.Drawing.Point(476, 44);
            this.FrequencyButton.Name = "FrequencyButton";
            this.FrequencyButton.Size = new System.Drawing.Size(77, 38);
            this.FrequencyButton.TabIndex = 8;
            this.FrequencyButton.Text = "send";
            this.FrequencyButton.UseVisualStyleBackColor = true;
            this.FrequencyButton.Click += new System.EventHandler(this.FrequencyButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(448, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(447, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "0-95 Degrees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(448, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "5-175 Degrees";
            // 
            // ConnectionPanel
            // 
            this.ConnectionPanel.BackColor = System.Drawing.Color.White;
            this.ConnectionPanel.Controls.Add(this.ButtonDisconnect);
            this.ConnectionPanel.Controls.Add(this.ButtonConnect);
            this.ConnectionPanel.Controls.Add(this.ComboBoxBaudRate);
            this.ConnectionPanel.Controls.Add(this.LabelBaudRate);
            this.ConnectionPanel.Controls.Add(this.ComboBoxPort);
            this.ConnectionPanel.Controls.Add(this.ButtonScanPort);
            this.ConnectionPanel.Controls.Add(this.ConnectionTitle);
            this.ConnectionPanel.Location = new System.Drawing.Point(191, 259);
            this.ConnectionPanel.Name = "ConnectionPanel";
            this.ConnectionPanel.Size = new System.Drawing.Size(362, 173);
            this.ConnectionPanel.TabIndex = 12;
            // 
            // ButtonDisconnect
            // 
            this.ButtonDisconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ButtonDisconnect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ButtonDisconnect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ButtonDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonDisconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonDisconnect.ForeColor = System.Drawing.Color.White;
            this.ButtonDisconnect.Location = new System.Drawing.Point(193, 118);
            this.ButtonDisconnect.Name = "ButtonDisconnect";
            this.ButtonDisconnect.Size = new System.Drawing.Size(143, 28);
            this.ButtonDisconnect.TabIndex = 6;
            this.ButtonDisconnect.Text = "Disconnect";
            this.ButtonDisconnect.UseVisualStyleBackColor = false;
            this.ButtonDisconnect.Click += new System.EventHandler(this.ButtonDisconnect_Click);
            // 
            // ButtonConnect
            // 
            this.ButtonConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ButtonConnect.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ButtonConnect.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ButtonConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonConnect.ForeColor = System.Drawing.Color.White;
            this.ButtonConnect.Location = new System.Drawing.Point(31, 118);
            this.ButtonConnect.Name = "ButtonConnect";
            this.ButtonConnect.Size = new System.Drawing.Size(143, 28);
            this.ButtonConnect.TabIndex = 5;
            this.ButtonConnect.Text = "Connect";
            this.ButtonConnect.UseVisualStyleBackColor = false;
            // 
            // ComboBoxBaudRate
            // 
            this.ComboBoxBaudRate.BackColor = System.Drawing.Color.Silver;
            this.ComboBoxBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxBaudRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBoxBaudRate.ForeColor = System.Drawing.Color.White;
            this.ComboBoxBaudRate.FormattingEnabled = true;
            this.ComboBoxBaudRate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.ComboBoxBaudRate.Location = new System.Drawing.Point(165, 80);
            this.ComboBoxBaudRate.Name = "ComboBoxBaudRate";
            this.ComboBoxBaudRate.Size = new System.Drawing.Size(121, 24);
            this.ComboBoxBaudRate.TabIndex = 4;
            // 
            // LabelBaudRate
            // 
            this.LabelBaudRate.AutoSize = true;
            this.LabelBaudRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelBaudRate.Location = new System.Drawing.Point(45, 82);
            this.LabelBaudRate.Name = "LabelBaudRate";
            this.LabelBaudRate.Size = new System.Drawing.Size(96, 18);
            this.LabelBaudRate.TabIndex = 3;
            this.LabelBaudRate.Text = "Baud Rate :";
            // 
            // ComboBoxPort
            // 
            this.ComboBoxPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ComboBoxPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComboBoxPort.FormattingEnabled = true;
            this.ComboBoxPort.Location = new System.Drawing.Point(165, 39);
            this.ComboBoxPort.Name = "ComboBoxPort";
            this.ComboBoxPort.Size = new System.Drawing.Size(121, 24);
            this.ComboBoxPort.TabIndex = 2;
            // 
            // ButtonScanPort
            // 
            this.ButtonScanPort.BackColor = System.Drawing.Color.Black;
            this.ButtonScanPort.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.ButtonScanPort.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.ButtonScanPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonScanPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonScanPort.ForeColor = System.Drawing.Color.White;
            this.ButtonScanPort.Location = new System.Drawing.Point(31, 39);
            this.ButtonScanPort.Name = "ButtonScanPort";
            this.ButtonScanPort.Size = new System.Drawing.Size(106, 30);
            this.ButtonScanPort.TabIndex = 1;
            this.ButtonScanPort.Text = "Scan Port";
            this.ButtonScanPort.UseVisualStyleBackColor = false;
            // 
            // ConnectionTitle
            // 
            this.ConnectionTitle.AutoSize = true;
            this.ConnectionTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConnectionTitle.ForeColor = System.Drawing.Color.LimeGreen;
            this.ConnectionTitle.Location = new System.Drawing.Point(81, 11);
            this.ConnectionTitle.Name = "ConnectionTitle";
            this.ConnectionTitle.Size = new System.Drawing.Size(183, 25);
            this.ConnectionTitle.TabIndex = 0;
            this.ConnectionTitle.Text = "Connection Panel";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(690, 470);
            this.Controls.Add(this.ConnectionPanel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FrequencyButton);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.FrequencyLabel);
            this.Controls.Add(this.PhaseShiftButton);
            this.Controls.Add(this.DutyCycleButton);
            this.Name = "Form1";
            this.Text = "Arduino Graphical User Interface in C#";
            this.ConnectionPanel.ResumeLayout(false);
            this.ConnectionPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button DutyCycleButton;
        private System.Windows.Forms.Button PhaseShiftButton;
        private System.Windows.Forms.Label FrequencyLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button FrequencyButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel ConnectionPanel;
        private System.Windows.Forms.Button ButtonScanPort;
        private System.Windows.Forms.Label ConnectionTitle;
        private System.Windows.Forms.ComboBox ComboBoxPort;
        private System.Windows.Forms.Label LabelBaudRate;
        private System.Windows.Forms.ComboBox ComboBoxBaudRate;
        private System.Windows.Forms.Button ButtonConnect;
        private System.Windows.Forms.Button ButtonDisconnect;
        private System.Windows.Forms.Timer TimerSerial;
    }
}

