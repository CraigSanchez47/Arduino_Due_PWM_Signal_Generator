﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Arduino_GUI_PWM_Control
{
    public partial class Form1 : Form
    {
        private string duty; // string to hold the duty cycle value
        private string phase; // string to hold the phase shift value

        public Form1()
        {
            InitializeComponent();
            serialPort1.Open();

        }

        private void FrequencyButton_Click(object sender, EventArgs e)
        {
            string m3 = "f" + textBox1.Text;
            serialPort1.Write(m3);
        }

        private void DutyCycleButton_Click(object sender, EventArgs e)
        {
            // Send command to the arduino to select Duty Cyle Mode 
            string m1 = "d" + textBox2.Text;
            serialPort1.Write(m1);
        }

        private void PhaseShiftButton_Click(object sender, EventArgs e)
        {
            // Send command to the arduino to select Phase shift Mode
            string m2 = "p" + textBox3.Text;
            serialPort1.Write(m2);
        }

        private void ButtonScanPort_Click(object sender, EventArgs e)
        {
            int i = 0;
            string[] ports = SerialPort.GetPortNames();
            Console.WriteLine("The Following serial ports were found");
            foreach(string port in ports)
            {
                ComboBoxPort.SelectedIndex= ports[i];
                i = i + 1;
            }
        }
        private void ButtonConnect_Click(object sender, EventArgs e)
        {
            this.serialPort1.PortName = ComboBoxPort.Text;
            this.serialPort1.BaudRate = ComboBoxBaudRate.SelectedIndex;
        }

        private void ButtonDisconnect_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
        }
    }
}
